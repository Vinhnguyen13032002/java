public class Applink {
    
}
